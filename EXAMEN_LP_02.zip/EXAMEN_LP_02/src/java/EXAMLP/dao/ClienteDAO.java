/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Interface.java to edit this template
 */
package EXAMLP.dao;

import EXAMLP.enty.Usuario;
import java.util.List;
import java.util.Map;


public interface ClienteDAO {
    int create(Usuario cliente);

    int update(Usuario cliente);

    int delete(int idcliente);

    Usuario read(int idcliente);
    List<Map<String , Object>> readAll();
}

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Interface.java to edit this template
 */
package EXAMLP.dao;

import EXAMLP.enty.Usuario;
import java.util.List;
import java.util.Map;


public interface UsuarioDAO {
    int create(Usuario usuario);
    
    int update(Usuario usuario);
    
    int delete(int idusuario);
    
    Usuario read(int idusuario);
    List<Map<String , Object>> readAll();
    
}

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Interface.java to edit this template
 */
package EXAMLP.dao;

import EXAMLP.enty.Sucursal;
import java.util.List;
import java.util.Map;


public interface SucursalDAO {
    int create(Sucursal sucursal);
    
    int update(Sucursal sucursal);
    
    int delete(int idsucursal);
    
    Sucursal read(int idsucursal);
    List<Map<String , Object>> readAll();
    
}

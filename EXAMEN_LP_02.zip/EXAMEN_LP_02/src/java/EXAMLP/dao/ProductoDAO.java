/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Interface.java to edit this template
 */
package EXAMLP.dao;

import EXAMLP.enty.Producto;
import EXAMLP.enty.Usuario;
import java.util.List;
import java.util.Map;


public interface ProductoDAO {
    int create(Producto producto);
    
    int update(Producto producto);
    
    int delete(int idproducto);
    
    Producto read(int idproducto);
    List<Map<String , Object>> readAll();
}

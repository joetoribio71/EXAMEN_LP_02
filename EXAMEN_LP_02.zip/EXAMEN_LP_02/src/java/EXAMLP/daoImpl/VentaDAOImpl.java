/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package EXAMLP.daoImpl;

import EXAMLP.config.conexion;
import EXAMLP.enty.Venta;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.List;
import java.util.Map;
import EXAMLP.dao.VentaDAO;


public class VentaDAOImpl implements VentaDAO {
    
    private PreparedStatement ps;
    private ResultSet rs;
    private Connection cx =null;

    @Override
    
    public int create(Venta v) {
        int id=0;
        String SQL="";
        try {
            cx =conexion.getConexion();
            ps =cx.prepareStatement(SQL , PreparedStatement.RETURN_GENERATED_KEYS);
            ps.setInt(1, v.getIdcliente());
            ps.setInt(2, v.getIdusuario());
            ps.setInt(3, v.getIdsucursal());
            ps.executeUpdate();
            ResultSet generatedKeys = ps.getGeneratedKeys();
            if (generatedKeys.next()){
                id=generatedKeys.getInt(1);
            }
        } catch (Exception e) {
            System.out.println("Error  "  + e);
        }
        return id;
    }

    @Override
    public List<Map<String, Object>> readdAll() {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }
    
}

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package EXAMLP.daoImpl;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import EXAMLP.config.conexion;
import EXAMLP.enty.Sucursal;
import EXAMLP.dao.SucursalDAO;
import java.util.HashMap;
import java.util.Map;


public class SucursalDAOImpl implements SucursalDAO {
    
    private PreparedStatement ps;
    private ResultSet rs;
    private Connection cx=null;
    
    @Override
    public List<Map<String, Object>> readAll() {
        String SQL= "select * from sucursales ";
        List<Map<String, Object>> lista = new ArrayList<>();
        try {
            cx = conexion.getConexion();
            ps = cx.prepareStatement(SQL);
            rs = ps.executeQuery();
            while (rs.next()) {
                Map<String, Object> map = new HashMap<>();
                map.put("idsucursal", rs.getInt("idsucursal"));
                map.put("nombre", rs.getString("nombre"));
                map.put("direccion", rs.getString("direccion"));                
                lista.add(map);
            }

        } catch (Exception e) {
            System.out.println("Error " + e);
        }
        return lista;
    }

    @Override
    public int create(Sucursal sucursal) {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    @Override
    public int update(Sucursal sucursal) {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    @Override
    public int delete(int idsucursal) {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    @Override
    public Sucursal read(int idsucursal) {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }
    
    
    
}

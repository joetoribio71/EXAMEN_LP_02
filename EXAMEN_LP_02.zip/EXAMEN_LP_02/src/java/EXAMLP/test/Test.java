/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package EXAMLP.test;

import com.google.gson.Gson;
import EXAMLP.config.conexion;
import EXAMLP.dao.UsuarioDAO;
import EXAMLP.daoImpl.UsuarioDAOImpl;



public class Test {
    static Gson g = new Gson();
    static UsuarioDAO sucu = new UsuarioDAOImpl();
    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here

        if (conexion.getConexion() != null) {
            System.out.println("si");
        } else {
            System.out.println("no");
        }
        System.out.println(g.toJson(sucu.readAll()));
    }

}

